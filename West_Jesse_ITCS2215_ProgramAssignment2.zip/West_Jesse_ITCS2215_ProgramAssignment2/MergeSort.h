#pragma once

#include<vector>

class MergeSort
{
public:
	void static mergeSort(int*, int, int);

private:
	void static merge(int*, int, int, int);
};
